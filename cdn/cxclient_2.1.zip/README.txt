Windows 10:
	Cortana: %appdata%
	-> .minecraft
	-> versions
	extract the cxclient_2.0 folder there

Mac:
	Just watch a tutorial or install windows or wait for me doing a tutorial.